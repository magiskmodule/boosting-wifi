### WiFi Boost&Opt v1.4 - 01.01.2023

* Improved Wi-Fi stability Fixed
  * Connection errors fixed
  * Fixed high power consumption
  * Fix bootloop
  * Fix old devices
  * Fix HotSpot
  * Fix Code

